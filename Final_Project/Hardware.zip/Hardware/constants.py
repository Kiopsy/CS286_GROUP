class c:
    WALL_THRESH = 0.1 # threshold used to determine whether value in grid is a wall
    ROBOT_INT = -100 # value of grid at robot's position
    FREE = 0 # value of grid when space is free
    WALL = 100 # value in gride when space is a wall
    UNEXPLORED = -1 # value in grid when space is unexplored